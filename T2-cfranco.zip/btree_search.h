#ifndef BTREE_SEARCH_H
#define BTREE_SEARCH_H

long search(bTree *bt, int id, char* filename);

#endif
