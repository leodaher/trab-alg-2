/*  Trabalho 3 - Algoritimos e Estruturas de Dados II
 *
 *  Desenvolvedores:
 *    Guilherme Prearo
 *    Gustavo Nicolau Goncalves
 *    Pedro V. B. Jeronymo
 *
 *  (Compilador gcc 4.9.2)
 */

#include "trabalho3.h"
#include "btree.h"


int reg_to_buffer(registro_t *reg, char buffer[REGFILE_BUFFERSIZE])
{
	sprintf(buffer, "%d|%s|%d|", reg->id, reg->nome, reg->tu);
	return strlen(buffer);
}

int file_to_reg(registro_t *reg, long offset, FILE *fd) {
	fseek(fd, offset, SEEK_SET) ;

	int size = 0;
	fscanf(fd, "%d", &size) ;

	if (size == 0) {
		return 0 ;
	}

	char *buffer = (char *) malloc(sizeof(char) * (size + 1)) ;
	fgets(buffer, size + 1, fd) ;

	char *p = strtok(buffer, "|") ;

	reg->id = atoi(p) ;
	p = strtok(NULL, "|") ;
	strcpy(reg->nome, p) ;
	strtok(NULL, "|") ;
	reg->tu = atoi(p) ;

	free(buffer) ;

	return 1 ;
}

long insert_reg(registro_t* reg, FILE* fdata)
{
	char buffer[REGFILE_BUFFERSIZE];
	char size = reg_to_buffer(reg, buffer);
	long offset = regfile_insert(buffer, size, fdata);
	return offset;
}

static void print_reg(registro_t *reg) {
	printf("ID: %d\n"
		   "Nome: %s\n"
		   "Tipo de usuário: %s\n", 
		   reg->id, reg->nome,
		   reg->tu == 0 ? "Gratuito" : (reg->tu == 1 ? "Comum" : "Premium"));
}

static void search_user(FILE *fdata, bTree *bt)
{
	int id ;
	printf("Informe o id do usuario a ser pesquisado: ");
	scanf("%d%*c", &id);
	
	long offset = search(bt, id) ;
	if (offset == -1) {
		printf("Usuário não existente!\n");
		return ;
	}

	registro_t reg ;
	if (!file_to_reg(&reg, offset, fdata)) {
		printf("Usuário não existente!\n");
		return ;
	}

	print_reg(&reg) ;
}


static void insert_user(FILE* fdata, bTree *bt)
{
	registro_t reg;
	printf("\n\nInsira os dados do novo usuario\n");
	printf("Id: ");
	scanf("%d%*c", &reg.id);
	if (search(bt, reg.id) != -1) {
		printf("Erro! Usuário existente!\n");
		return ;
	}
	printf("Nome completo: ");
	fgets(reg.nome, sizeof(reg.nome), stdin);
	reg.nome[strlen(reg.nome)-1] = '\0';
	printf("Insira o tipo de usuario(TU):\n1. gratuito\n2. comum\n3. premium\nCodigo numerico: ");
	scanf("%d%*c", &reg.tu);
	switch(reg.tu) {
	case 1:
	case 2:
	case 3:
		break;
	default:
		printf("\n<Erro: insira um tipo de usuario valido>\n");
		return; //Retorna ao menu
		break;
	}
	long offset = insert_reg(&reg, fdata);
	insert(bt, reg.id, offset) ;
	printf("\n<Usuario inserido com sucesso>\n");
}

static void remove_user(FILE* fdata, bTree *bt)
{
	printf("Indique o ID do usuario: ");
	int id;
	scanf("%d%*c", &id);
	long offset = search(bt, id);
	if (offset == -1) {
		printf("Usuário não encontrado!\n") ;
		return ;
	}
	regfile_remove(offset, fdata);
	printf("\n<Usuario removido com sucesso>\n");
}


static int ui(FILE* fdata, bTree *bt)
{
	printf("\n\n::Bem-vindo ao T3 de Alg2::\n\n");
	printf("Desenvolvedores:\n\tGuilherme Prearo\n\tGustavo N. Goncalves\n\tPedro V. B. Jeronymo\n\n\n");

	char run = 1;

	while(run)
	{
		int op;
		printf("\n\nSelecione uma operacao de acordo com seu codigo numerico:\n");
		printf("1. Inserir usuario\n2. Remover usuario\n3. Pesquisar por ID\n5. Fechar o programa\n");
		printf("\nOperacao:> ");
		scanf("%d%*c", &op);
		switch(op) {
		case 1:
			insert_user(fdata, bt);
			break;
		case 2:
			remove_user(fdata, bt);
			break;
		case 3:
			search_user(fdata, bt);
			break;
		case 4:
			///print B-Tree
			break;
		case 5:
			run = 0;
			break;
		default:
			printf("\n<Erro: selecione uma operacao valida>\n");
			break;
		}
	}

	return 0;
}

static int openfile(const char* filename, FILE** fd)
{
	//*fd = fopen(filename, "rb+");
	*fd = fopen(filename, "r+");
	if(!*fd)
	{
		//*fd = fopen(filename, "wb+");
		*fd = fopen(filename, "w+");
		if(!*fd)
		{
			return -1;
		} 
	}	
	return 0;
}

int main(void)
{
	FILE *fdata ;
	int err;

	bTree bt ;
	initBT(&bt) ;
	
	err = openfile(DATA_FILE, &fdata);
	if(err) return err;

	err = ui(fdata, &bt);
	if(err) return err;

	fclose(fdata);
	return 0;
}